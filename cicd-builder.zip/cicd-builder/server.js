/**
 * CI/CD Builder — server.js
 * 4 endpoints: /api/build, /api/logs (SSE), /api/generate-yaml, /api/status
 */

const http = require("http");
const fs = require("fs");
const path = require("path");
const { execFile, spawn } = require("child_process");
const crypto = require("crypto");

// ── Config ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
const BUILD_DIR = path.join(__dirname, ".builds");
if (!fs.existsSync(BUILD_DIR)) fs.mkdirSync(BUILD_DIR, { recursive: true });

// In-memory store for build jobs  { [id]: { status, logs[], startedAt, finishedAt } }
const jobs = new Map();

// SSE subscribers  { [jobId]: Set<res> }
const sseClients = new Map();

// ── Helpers ───────────────────────────────────────────────────────────────────
function uid() {
  return crypto.randomBytes(6).toString("hex");
}

function send(res, status, body) {
  const json = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
  });
  res.end(json);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (c) => (data += c));
    req.on("end", () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch {
        reject(new Error("Invalid JSON"));
      }
    });
    req.on("error", reject);
  });
}

function pushLog(jobId, line) {
  const job = jobs.get(jobId);
  if (!job) return;
  const entry = { t: Date.now(), msg: line };
  job.logs.push(entry);

  // fan-out to all SSE clients watching this job
  const clients = sseClients.get(jobId);
  if (clients) {
    const data = `data: ${JSON.stringify(entry)}\n\n`;
    for (const clientRes of clients) {
      try { clientRes.write(data); } catch { /* closed */ }
    }
  }
}

function finishJob(jobId, status) {
  const job = jobs.get(jobId);
  if (!job) return;
  job.status = status;
  job.finishedAt = Date.now();
  pushLog(jobId, `[done] Build ${status}`);

  // close SSE streams
  const clients = sseClients.get(jobId);
  if (clients) {
    const closeMsg = `data: ${JSON.stringify({ t: Date.now(), msg: "__DONE__", status })}\n\n`;
    for (const clientRes of clients) {
      try { clientRes.write(closeMsg); clientRes.end(); } catch { /* ok */ }
    }
    sseClients.delete(jobId);
  }
}

// ── Fake build pipeline (swap with real docker/npm/etc. commands) ──────────────
function runBuild(jobId, { repo, branch = "main", runtime = "node", envVars = {} }) {
  const job = jobs.get(jobId);
  job.status = "running";

  const steps = [
    { label: "Cloning repository", cmd: ["echo", [`Cloning ${repo}@${branch}...`]] },
    { label: "Installing dependencies", cmd: ["echo", ["Installing packages..."]] },
    { label: "Running tests", cmd: ["echo", ["Running test suite..."]] },
    { label: "Building artifacts", cmd: ["echo", ["Compiling assets..."]] },
    { label: "Packaging Docker image", cmd: ["echo", [`docker build -t app:${jobId} .`]] },
    { label: "Pushing to registry", cmd: ["echo", ["Pushed successfully."]] },
  ];

  (async () => {
    try {
      for (let i = 0; i < steps.length; i++) {
        const step = steps[i];
        pushLog(jobId, `[step ${i + 1}/${steps.length}] ${step.label}`);
        await new Promise((res) => setTimeout(res, 800 + Math.random() * 600));

        // Simulate occasional command output
        pushLog(jobId, `  ✓ ${step.cmd[1][0]}`);
        await new Promise((res) => setTimeout(res, 200));
      }

      // Write a build report
      const reportPath = path.join(BUILD_DIR, `${jobId}.json`);
      fs.writeFileSync(
        reportPath,
        JSON.stringify({ jobId, repo, branch, runtime, envVars: Object.keys(envVars), finishedAt: Date.now() }, null, 2)
      );

      finishJob(jobId, "success");
    } catch (err) {
      pushLog(jobId, `[error] ${err.message}`);
      finishJob(jobId, "failed");
    }
  })();
}

// ── GitHub Actions YAML generator ─────────────────────────────────────────────
function generateYAML({ repo, branch = "main", runtime = "node", nodeVersion = "20", registryImage = "ghcr.io/you/app", envVars = [], steps: extraSteps = [] }) {
  const runtimeSetup = runtime === "node"
    ? `      - name: Setup Node.js\n        uses: actions/setup-node@v4\n        with:\n          node-version: '${nodeVersion}'\n          cache: 'npm'`
    : runtime === "python"
    ? `      - name: Setup Python\n        uses: actions/setup-python@v5\n        with:\n          python-version: '3.12'`
    : `      - name: Setup Go\n        uses: actions/setup-go@v5\n        with:\n          go-version: '1.22'`;

  const installCmd = runtime === "node" ? "npm ci" : runtime === "python" ? "pip install -r requirements.txt" : "go mod download";
  const testCmd = runtime === "node" ? "npm test" : runtime === "python" ? "pytest" : "go test ./...";
  const buildCmd = runtime === "node" ? "npm run build" : runtime === "python" ? "python -m build" : "go build ./...";

  const envBlock = envVars.length
    ? `    env:\n${envVars.map((e) => `      ${e}: \${{ secrets.${e.toUpperCase()} }}`).join("\n")}`
    : "";

  return `# Auto-generated by CI/CD Builder
# Repo: ${repo} | Branch: ${branch}

name: CI/CD Pipeline

on:
  push:
    branches: [ ${branch} ]
  pull_request:
    branches: [ ${branch} ]

env:
  REGISTRY: ghcr.io
  IMAGE_NAME: ${registryImage}

jobs:
  test:
    name: Test
    runs-on: ubuntu-latest
    steps:
      - name: Checkout code
        uses: actions/checkout@v4

${runtimeSetup}

      - name: Install dependencies
        run: ${installCmd}
${envBlock}

      - name: Run tests
        run: ${testCmd}
${envBlock}

  build:
    name: Build & Push Docker Image
    runs-on: ubuntu-latest
    needs: test
    if: github.event_name == 'push'
    permissions:
      contents: read
      packages: write

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

${runtimeSetup}

      - name: Install dependencies
        run: ${installCmd}

      - name: Build application
        run: ${buildCmd}

      - name: Log in to Container Registry
        uses: docker/login-action@v3
        with:
          registry: \${{ env.REGISTRY }}
          username: \${{ github.actor }}
          password: \${{ secrets.GITHUB_TOKEN }}

      - name: Extract Docker metadata
        id: meta
        uses: docker/metadata-action@v5
        with:
          images: \${{ env.IMAGE_NAME }}
          tags: |
            type=sha,prefix=sha-
            type=ref,event=branch
            type=raw,value=latest,enable={{is_default_branch}}

      - name: Build and push Docker image
        uses: docker/build-push-action@v5
        with:
          context: .
          push: true
          tags: \${{ steps.meta.outputs.tags }}
          labels: \${{ steps.meta.outputs.labels }}
          cache-from: type=gha
          cache-to: type=gha,mode=max

  deploy:
    name: Deploy
    runs-on: ubuntu-latest
    needs: build
    environment: production

    steps:
      - name: Deploy to production
        run: |
          echo "Deploying \${{ env.IMAGE_NAME }}:sha-\${{ github.sha }}"
          # Add your deploy command here:
          # ssh user@host "docker pull && docker-compose up -d"
          # OR: kubectl set image deployment/app app=\${{ env.IMAGE_NAME }}:sha-\${{ github.sha }}
`;
}

// ── Router ────────────────────────────────────────────────────────────────────
async function router(req, res) {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const pathname = url.pathname;
  const method = req.method;

  // CORS preflight
  if (method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    });
    return res.end();
  }

  // ── POST /api/build ──────────────────────────────────────────────────────────
  if (pathname === "/api/build" && method === "POST") {
    let body;
    try { body = await readBody(req); }
    catch { return send(res, 400, { error: "Invalid JSON" }); }

    const { repo, branch, runtime, envVars } = body;
    if (!repo) return send(res, 400, { error: "repo is required" });

    const jobId = uid();
    jobs.set(jobId, { id: jobId, status: "queued", logs: [], startedAt: Date.now(), finishedAt: null, repo, branch, runtime });

    // Kick off async build
    runBuild(jobId, { repo, branch, runtime, envVars });

    return send(res, 202, { jobId, status: "queued", logsUrl: `/api/logs/${jobId}`, statusUrl: `/api/status/${jobId}` });
  }

  // ── GET /api/logs/:jobId  (Server-Sent Events) ────────────────────────────────
  const logsMatch = pathname.match(/^\/api\/logs\/([a-f0-9]+)$/);
  if (logsMatch && method === "GET") {
    const jobId = logsMatch[1];
    const job = jobs.get(jobId);
    if (!job) return send(res, 404, { error: "Job not found" });

    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      "Connection": "keep-alive",
      "Access-Control-Allow-Origin": "*",
    });

    // Replay existing logs first
    for (const entry of job.logs) {
      res.write(`data: ${JSON.stringify(entry)}\n\n`);
    }

    // If already done, close immediately
    if (job.status === "success" || job.status === "failed") {
      res.write(`data: ${JSON.stringify({ t: Date.now(), msg: "__DONE__", status: job.status })}\n\n`);
      return res.end();
    }

    // Register as live subscriber
    if (!sseClients.has(jobId)) sseClients.set(jobId, new Set());
    sseClients.get(jobId).add(res);

    req.on("close", () => {
      sseClients.get(jobId)?.delete(res);
    });

    return; // keep connection open
  }

  // ── GET /api/status/:jobId ────────────────────────────────────────────────────
  const statusMatch = pathname.match(/^\/api\/status\/([a-f0-9]+)$/);
  if (statusMatch && method === "GET") {
    const jobId = statusMatch[1];
    const job = jobs.get(jobId);
    if (!job) return send(res, 404, { error: "Job not found" });

    return send(res, 200, {
      jobId: job.id,
      status: job.status,
      repo: job.repo,
      branch: job.branch,
      runtime: job.runtime,
      startedAt: job.startedAt,
      finishedAt: job.finishedAt,
      logCount: job.logs.length,
    });
  }

  // ── POST /api/generate-yaml ───────────────────────────────────────────────────
  if (pathname === "/api/generate-yaml" && method === "POST") {
    let body;
    try { body = await readBody(req); }
    catch { return send(res, 400, { error: "Invalid JSON" }); }

    const yaml = generateYAML(body);
    return send(res, 200, { yaml });
  }

  // ── GET / → serve frontend ────────────────────────────────────────────────────
  if (pathname === "/" && method === "GET") {
    const indexPath = path.join(__dirname, "public", "index.html");
    if (fs.existsSync(indexPath)) {
      res.writeHead(200, { "Content-Type": "text/html" });
      return res.end(fs.readFileSync(indexPath));
    }
  }

  send(res, 404, { error: "Not found" });
}

// ── Start ─────────────────────────────────────────────────────────────────────
const server = http.createServer(router);
server.listen(PORT, () => {
  console.log(`\n🚀 CI/CD Builder running at http://localhost:${PORT}\n`);
  console.log("Endpoints:");
  console.log("  POST /api/build          → Start a build job");
  console.log("  GET  /api/logs/:jobId    → SSE live log stream");
  console.log("  GET  /api/status/:jobId  → Poll job status");
  console.log("  POST /api/generate-yaml  → Generate GitHub Actions YAML\n");
});
